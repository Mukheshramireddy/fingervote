﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;

namespace Finger_ATM
{
    public partial class CandidateList : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=SG2NWPLS14SQL-v09.shr.prod.sin2.secureserver.net;Initial Catalog=FingerVote;Persist Security Info=True;User ID=FingerVote;Password=93Rdme3%");
        public static string sessionedit_cid = "";
        public CandidateList()
        {
            InitializeComponent();
        }

        private void CandidateList_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("CId");
            dt.Columns.Add("CName");
            dt.Columns.Add("email_id");
            dt.Columns.Add("desc");
            SqlCommand cmd = new SqlCommand("Select CId, symbol, Image, Name, email_id, des from Candidate ", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                while(dr.Read())
                {
                    dt.Rows.Add(dr["CId"].ToString(), dr["Name"].ToString(), dr["email_id"].ToString(), dr["des"].ToString());
                }
            }
            con.Close();
            dataGridView1.DataSource = dt;
            foreach (DataGridViewRow myrow in dataGridView1.Rows)
            {
                myrow.Height = 150;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            if (dataGridView1.Columns[e.ColumnIndex].Name == "Edit")
            {
                sessionedit_cid = id;
                CandidateList hm = new CandidateList();
                hm.Hide();
                AddCandidate reg = new AddCandidate();
                reg.MdiParent = this.MdiParent;
                reg.Show();
            }
            else if (dataGridView1.Columns[e.ColumnIndex].Name == "Delete")
            {
                if (MessageBox.Show("Are You sure want to delete this record ?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    SqlCommand cmd = new SqlCommand("delete from Candidate where CId = '" + id + "'", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    CandidateList_Load(this, EventArgs.Empty);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Finger_ATM
{
    public partial class AddCandidate : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=SG2NWPLS14SQL-v09.shr.prod.sin2.secureserver.net;Initial Catalog=FingerVote;Persist Security Info=True;User ID=FingerVote;Password=93Rdme3%"); 
        
        public AddCandidate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Image = new Bitmap(open.FileName);
                pictureBox2.Image.Save(@"Candidate\" + textBox1.Text + ".jpg");
            }
        }

        public void id()
        {
            string com = "select top 1 CId From Candidate ORDER BY cId Desc;";
            con.Open();
            SqlCommand cmd = new SqlCommand(com, con);
            object count = cmd.ExecuteScalar();
            if (count != null)
            {
                int i = Convert.ToInt32(count);
                i++;
                textBox1.Text = i.ToString();
            }
            else
            {
                textBox1.Text = "101";
            }
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Candidate where email_id = '"+email_id.Text.Trim()+"'", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if(ds.Tables[0].Rows.Count > 0)
            {
                MessageBox.Show("You Have Already registered..!!", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || email_id.Text.Trim() == "")
                {
                    MessageBox.Show("Please Fill all Data", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (pictureBox2.Image == null)
                {
                    MessageBox.Show("Please Select Candidate Image", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (election_symbol.Image == null)
                {
                    MessageBox.Show("Please Select Election Symbol", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("Insert into Candidate Values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + @"symbol\" + textBox1.Text + ".jpg" + "','" + email_id.Text.Trim() + "','" + @"Candidate\" + textBox1.Text + ".jpg" + "')", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    DialogResult d = MessageBox.Show("Candidate Registered Successfully", "Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (d == DialogResult.OK)
                    {
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        pictureBox2.Image = null;
                        election_symbol.Image = null;
                        email_id.Text = "";
                        id();
                    }
                }
            }
        }

        private void AddCandidate_Load(object sender, EventArgs e)
        {
            id();
            if (CandidateList.sessionedit_cid != null)
            {
                textBox1.Text = CandidateList.sessionedit_cid;
                SqlCommand cmd = new SqlCommand("select * from Candidate where CId = '" + textBox1.Text + "'", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    textBox2.Text = dr["Name"].ToString();
                    textBox3.Text = dr["Des"].ToString();
                    pictureBox2.ImageLocation = dr["Image"].ToString();
                    election_symbol.ImageLocation = dr["symbol"].ToString();
                    email_id.Text = dr["email_id"].ToString();
                    add.Visible = false;
                    update.Visible = true;
                    button1.Enabled = false;
                    button2.Enabled = false;
                    textBox2.ReadOnly = true;
                    textBox1.ReadOnly = true;
                }
                con.Close();
                CandidateList.sessionedit_cid = null;
            }
            else
            {
                add.Visible = true;
                update.Visible = false;
                button1.Enabled = true;
                textBox2.ReadOnly = false;
                button2.Enabled = true;
                textBox1.ReadOnly = false;
                CandidateList.sessionedit_cid = null;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                election_symbol.Image = new Bitmap(open.FileName);
                election_symbol.Image.Save(@"symbol\" + textBox1.Text + ".jpg");
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Candidate where email_id = '" + email_id.Text.Trim() + "' and CId != '"+textBox1.Text+"'", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                MessageBox.Show("You Have Already registered..!!", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || email_id.Text.Trim() == "")
                {
                    MessageBox.Show("Please Fill all Data", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (pictureBox2.Image == null)
                {
                    MessageBox.Show("Please Select Candidate Image", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (election_symbol.Image == null)
                {
                    MessageBox.Show("Please Select Election Symbol", "Error !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("update Candidate set Name = '" + textBox2.Text + "', email_id = '" + email_id.Text.Trim() + "', des = '" + textBox3.Text + "' where CId = '"+textBox1.Text+"'", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    DialogResult d = MessageBox.Show("Candidate Updated Successfully", "Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (d == DialogResult.OK)
                    {
                        AddCandidate hm = new AddCandidate();
                        hm.Hide();
                        CandidateList reg = new CandidateList();
                        reg.MdiParent = this.MdiParent;
                        reg.Show();
                    }
                }
            }
        }
    }
}

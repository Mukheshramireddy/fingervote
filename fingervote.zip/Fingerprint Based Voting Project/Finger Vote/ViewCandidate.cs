﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Finger_ATM
{
    public partial class ViewCandidate : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=SG2NWPLS14SQL-v09.shr.prod.sin2.secureserver.net;Initial Catalog=FingerVote;Persist Security Info=True;User ID=FingerVote;Password=93Rdme3%");
        
        public ViewCandidate()
        {
            InitializeComponent();
        }

        string cname = "";
        public ViewCandidate(string cname1)
        {
            InitializeComponent();
            cname = cname1;
        }

        private void ViewCandidate_Load(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from Candidate where Name ='"+cname+"'",con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();
            textBox1.Text = cname;
            pictureBox2.ImageLocation = dr["Image"].ToString();
            symbol.ImageLocation = dr["symbol"].ToString();
            textBox2.Text = dr["Des"].ToString();
            con.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
